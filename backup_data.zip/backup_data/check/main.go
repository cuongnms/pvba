package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strings"
)

type Prices struct {
	Bank       map[string]int `json:"bank"`
	Credit     map[string]int `json:"credit"`
	EWallet    map[string]int `json:"e-wallet"`
	GooglePlay map[string]int `json:"google-play"`
	TPB        map[string]int `json:"tpb"`
	VietQR     map[string]int `json:"viet-qr"`
}

type Package struct {
	Description string  `json:"description"`
	IapImage    string  `json:"iapImage"`
	ID          string  `json:"id"`
	Image       string  `json:"image"`
	Instruction string  `json:"instruction"`
	Name        string  `json:"name"`
	Prices      *Prices `json:"prices"`
}

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: go run main.go <input.txt>")
		return
	}

	inputFile := os.Args[1]
	file, err := os.Open(inputFile)
	if err != nil {
		panic(err)
	}
	defer file.Close()

	packages := map[string]*Package{}
	baseURL := "https://h5.zadn.vn/games/tctd/payment-package"

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}

		// Tách các phần bằng dấu phẩy
		parts := strings.Split(line, ",")
		if len(parts) < 4 {
			fmt.Printf("⚠️  Bỏ qua dòng không hợp lệ: %s\n", line)
			continue
		}

		id := strings.TrimSpace(parts[0])
		name := strings.Trim(strings.TrimSpace(parts[1]), `"`)
		priceBank := strings.TrimSpace(parts[2])
		priceGoogle := strings.TrimSpace(parts[3])

		var bankPrice, googlePrice int
		fmt.Sscanf(priceBank, "%d", &bankPrice)
		fmt.Sscanf(priceGoogle, "%d", &googlePrice)

		packages[id] = &Package{
			Description: name,
			IapImage:    fmt.Sprintf("%s/%s-iap.jpg", baseURL, id),
			ID:          id,
			Image:       fmt.Sprintf("%s/%s.jpg", baseURL, id),
			Instruction: "",
			Name:        name,
			Prices: &Prices{
				Bank:       map[string]int{"default": bankPrice},
				Credit:     map[string]int{"CC": bankPrice},
				EWallet:    map[string]int{"38": bankPrice},
				GooglePlay: map[string]int{"220": googlePrice},
				TPB:        map[string]int{"42": bankPrice},
				VietQR:     map[string]int{"39": bankPrice},
			},
		}
	}

	if err := scanner.Err(); err != nil {
		panic(err)
	}

	jsonData, err := json.MarshalIndent(packages, "", "  ")
	if err != nil {
		panic(err)
	}

	fmt.Println(string(jsonData))
}
